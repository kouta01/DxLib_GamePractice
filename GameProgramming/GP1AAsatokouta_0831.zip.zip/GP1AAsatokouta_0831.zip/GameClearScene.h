#pragma once

/**************************
*�}�N����`
**************************/

/**************************
*�^��`
**************************/

/**************************
*�v���g�^�C�v�錾
**************************/

int GameClearScene_Initialize(void);

void GameClearScene_Update(void);

void GameClearScene_Draw(void);